from distutils.core import setup
setup(name='py-url-shortener',
      version='1.0',
      author='Andy Wong',
      author_email='awong.cm@gmail.com',
      url='https://github.com/awongCM/py-url-shortener'
    )